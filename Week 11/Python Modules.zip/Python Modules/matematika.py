PI = 3.14

def luas_lingkaran(jari_jari):
    return PI * jari_jari * jari_jari

def luas_persegi(sisi):
    return sisi * sisi